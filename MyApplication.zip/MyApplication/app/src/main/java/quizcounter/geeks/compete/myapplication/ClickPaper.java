package quizcounter.geeks.compete.myapplication;

public interface ClickPaper {
     void onClickPaperItem();
}
