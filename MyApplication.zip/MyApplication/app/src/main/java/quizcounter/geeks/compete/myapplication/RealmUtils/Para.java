package quizcounter.geeks.compete.myapplication.RealmUtils;

public class Para {
    public String paraId;
    public String paraData;
    public String list_Q;
}
