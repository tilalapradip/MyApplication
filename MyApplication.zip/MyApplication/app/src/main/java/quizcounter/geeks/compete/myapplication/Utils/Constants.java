package quizcounter.geeks.compete.myapplication.Utils;

public class Constants {
    public static String Notif="Notif";
//    public static String Papers="Papers";
    public static String NotifIdList="NotifIdList";
    public static String paperIdList="paperIdList";
    public static String isUpdated="isUpdated";
    public static String Papers="Papers";
    public static String Notifications="Notifications";
    public static String type="type";
    public static String webview_title = "webview_title";
    public static String urlWooplrWebView = "urlWooplrWebView";
}
