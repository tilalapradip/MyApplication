package quizcounter.geeks.compete.myapplication;

import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.HashMap;

import io.realm.Realm;
import io.realm.RealmResults;
import quizcounter.geeks.compete.myapplication.RealmUtils.Paper;
import quizcounter.geeks.compete.myapplication.RealmUtils.Qnew;

public class TestActivity extends AppCompatActivity {
    String id="";
    ViewPager viewPager;
    String APIResponse;
    SectionFragmentPagerAdapter sectionPagerAdapter;
    ArrayList<Qnew> qnewArrayList=new ArrayList<>();
    Toolbar toolbar;
    Button btn_previous,btn_next,btn_end;
    TextView tvTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        viewPager=findViewById(R.id.viewpager_test);
        toolbar=findViewById(R.id.toolbar);
        tvTitle=findViewById(R.id.title);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        String title= getIntent().getExtras().getString("title");
        tvTitle.setText(title);

        sectionPagerAdapter=new SectionFragmentPagerAdapter(getSupportFragmentManager());
//        viewPager.setOffscreenPageLimit(50);
        viewPager.setOffscreenPageLimit(2);

        id= getIntent().getExtras().getString("id");

//        Paper paper=Realm.getDefaultInstance().where(Paper.class).equalTo("paperId",id).findFirst();
//        APIResponse=paper.paperData;
//        Log.e("PAperData", "onCreate: "+paper.toString());
//        parseData();

        btn_previous=findViewById(R.id.btn_previous);
        btn_next=findViewById(R.id.btn_next);
        btn_end=findViewById(R.id.btn_end);


        btn_end.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });

        btn_previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClick(-1);
            }
        });

        btn_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClick(1);
            }
        });

        getQuestionsRealm(id);

    }

    private void getQuestionsRealm(String id) {
//        UGC_NET_Paper_1_July_2019
        Realm realm=Realm.getDefaultInstance();
        RealmResults<Qnew> qnewRealmResults=realm.where(Qnew.class).equalTo("Pid",id).findAll();
        qnewArrayList.addAll(realm.copyFromRealm(qnewRealmResults));
        realm.close();
        setDataTofragments();

        //        .equalTo("Pid",id)
//        for(int i=0;i<qnewRealmResults.size();i++){
//            qnewRealmResults
//            Log.e("qnewRealmResults::",id+"::"+qnewRealmResults.get(i).Pid);
//        }
//        Log.e("qnewRealmResults::",id+"::"+qnewRealmResults.size());
    }

    void setDataTofragments(){
        for(int i=0;i<qnewArrayList.size();i++){
            sectionPagerAdapter.addFragment(BlankFragment.newInstance(qnewArrayList.get(i),this));
        }
        viewPager.setAdapter(sectionPagerAdapter);
    }

    public void onItemClick(int i){
        viewPager.setCurrentItem(viewPager.getCurrentItem()+i);
    }

//    void parseData(){
//        Document document = Jsoup.parse(APIResponse);
//        Elements nodeBlogStats = document.getElementsByClass("question-data");
//        ArrayList<Element> elementArrayList=new ArrayList<>();
//        ArrayList<Element> elementArrayPara=new ArrayList<>();
//        HashMap<String,Integer> hashMap=new HashMap<>();
////        for (Element row : nodeBlogStats) {
//        for (int e=0;e<nodeBlogStats.size();e++) {
////            Log.e("DataParsedAPI","::"+e+"::"+nodeBlogStats.get(e).attr("referenced_by"));
//
//            if(!"".equalsIgnoreCase(nodeBlogStats.get(e).attr("referenced_by").toString())){
//                elementArrayPara.add(nodeBlogStats.get(e));
//                String[] items = nodeBlogStats.get(e).attr("referenced_by").toString().split(",");
//                for(int i=0;i<items.length;i++){
//                    hashMap.put(items[i],elementArrayPara.size()-1);
//                }
//            }else {
//                elementArrayList.add(nodeBlogStats.get(e));
//            }
//        }
//
//        for (int i=0;i<elementArrayList.size();i++) {
//            BlankFragment blankFragment = null;
//            if(hashMap.containsKey(""+(i+1))){
//                Element para=elementArrayPara.get(hashMap.get(""+(i+1)));
//                blankFragment=BlankFragment.newInstance(elementArrayList.get(i).toString(),para+"</br>",this);
//            }else {
//                blankFragment=BlankFragment.newInstance(elementArrayList.get(i).toString(),"",this);
//            }
////            BlankFragment blankFragment=BlankFragment.newInstance(elementArrayList.get(i).toString());
//            sectionPagerAdapter.addFragment(blankFragment);
//        }
//        viewPager.setAdapter(sectionPagerAdapter);
//    }


}
