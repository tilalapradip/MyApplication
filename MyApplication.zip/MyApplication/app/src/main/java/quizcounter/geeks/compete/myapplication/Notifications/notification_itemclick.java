package quizcounter.geeks.compete.myapplication.Notifications;

/**
 * Created by espl on 3/5/17.
 */

public interface notification_itemclick {
    void notificationData(String result);
}
