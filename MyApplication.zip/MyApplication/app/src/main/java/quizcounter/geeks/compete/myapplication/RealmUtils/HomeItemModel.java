package quizcounter.geeks.compete.myapplication.RealmUtils;

import java.util.ArrayList;

public class HomeItemModel {
    public String title;
    public ArrayList<String> itemIds=new ArrayList<>();
}
